@extends('layouts.app')

@section('content')
    <div class="container">

        <!-- Select Product Modal -->
        <div id="select-product-modal" class="modal" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header justify-content-center">
                        <h5 class="modal-title">انتخاب کالا</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group row">
                            <div class="form-group col-6">
                                <label for="select-main-category">دسته</label>
                                <select class="custom-select catselect" id="select-main-category">
                                    <option id="reset-first" selected="selected">لطفا انتخاب کنید</option>
                                    @foreach($categories as $category)
                                        <option class="category-level-one"
                                                value="{{ $category->id }}">{{ $category->title }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group col-6">
                                <label for="product-selector">کالا</label>
                                <select class="custom-select" id="product-selector">
                                    <option selected="selected">لطفا انتخاب کنید</option>
                                    @foreach($products as $product)
                                        <option value="{{ $product->id }}">{{ $product->title }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">تایید</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Select Worker Modal -->
        <div id="select-worker-modal" class="modal" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header justify-content-center">
                        <h5 class="modal-title">انتخاب وارد کننده</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group row">
                            <div class="form-group col-6">
                                <label for="select-main-category">نقش</label>
                                <select class="custom-select catselect" id="select-main-category">
                                    <option id="reset-first" selected="selected">لطفا انتخاب کنید</option>
                                    @foreach($roles as $role)
                                        <option class="category-level-one"
                                                value="{{ $role->id }}">{{ $role->title }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group col-6">
                                <label for="product-selector">شخص</label>
                                <select class="custom-select" id="product-selector">
                                    <option selected="selected">لطفا انتخاب کنید</option>
                                    @foreach($workers as $worker)
                                        <option value="{{ $worker->id }}">{{ $worker->title }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">تایید</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-light">{{ __('ثبت ورود به انبار') }}</div>

                    <div class="card-body">
                        <form id="new-entry" method="post" action="">
                            @csrf

                            <div class="form-group row">
                                <div class="form-group col-2">
                                    <label for="date">تاریخ</label>
                                    <input type="text" id="date" name="date" class="form-control form-control-sm" value="{{ $date }}"
                                           data-jdp required>
                                </div>
                                <div class="form-group col-2">
                                    <label for="code">شماره رسید</label>
                                    <input type="text" id="code" name="code" class="form-control form-control-sm" required>
                                </div>
                                <div class="form-group col-2">
                                    <label for="worker">وارد کننده</label>
                                    <input type="text" id="worker" name="worker"
                                           class="form-control text-dark bg-white form-control-sm" required>
                                    <input type="hidden" id="worker-id" name="worker_id" value="">
                                </div>
                            </div>

                            <div class="form-group row custom-single-product">
                                <div class="form-group col-3">
                                    <label for="product">کالا</label>
                                    <input type="text" id="product" name="product"
                                           class="form-control text-dark bg-white form-control-sm" required>
                                    <input type="hidden" id="product-id" name="product_id[]" value="">
                                </div>
                                <div class="form-group col-2">
                                    <label for="value">مقدار</label>
                                    <input type="text" id="value" name="value[]" class="form-control form-control-sm" required>
                                </div>
                                <div class="form-group col-2">
                                    <label for="value">قیمت (ريال)</label>
                                    <input type="text" id="value" name="value[]" class="form-control form-control-sm" required>
                                </div>
                                <div class="form-group col-2">
                                    <label for="store">انبار</label>
                                    <select class="custom-select custom-select-sm" id="store" name="store[]" required>
                                        <option selected="selected">لطفا انتخاب کنید</option>
                                        @foreach($stores as $store)
                                            <option class="category-level-one"
                                                    value="{{ $store->id }}">{{ $store->title }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group col-3">
                                    <label for="description">توضیحات</label>
                                    <input type="text" id="description" name="description[]" class="form-control form-control-sm">
                                </div>
                            </div>

                        </form>
                        <div class="w-100 text-center">
                            <p class="custom-add-row-icon">افزودن کالا <span class="fa fa-plus mr-2"></span></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function () {

            jalaliDatepicker.startWatch();

            const singleProductRow = $('#new-entry .custom-single-product').html();

            $("#new-entry input").val('');
            $('#select-product-modal .modal-body #select-main-category #reset-first').attr('selected', 'selected');
            $('#select-product-modal .modal-body .children-selector').remove();
            $('#select-product-modal .modal-body .end-selector').remove();
            $("#date").val("{{ $date }}");

            $("#new-entry").on('click', '#product', function () {
                $("#select-product-modal").modal('show');
                $(".current-product-active").removeClass('current-product-active');
                $(this).addClass('current-product-active');
            });
            $("#new-entry").on('click', '#worker', function () {
                $("#select-worker-modal").modal('show');
            });

            function getProducts(categoryID){
                $('#select-product-modal #product-selector').children().remove();
                $.ajax({
                    url: "{{ url('/') }}/products/bycategory/" + categoryID,
                    method: "get",
                    success: function (response) {
                        const data = response;
                        if (data.length > 0) {
                            data.forEach(element => {
                                $("#select-product-modal #product-selector").append("<option value='" + element.id + "'>" + element.title + "</option>")
                            });
                        } else {
                            $("#select-product-modal #product-selector").append("<option>کالایی وجود ندارد!</option>");
                            $('#select-product-modal #product-selector option:first-child').attr('selected','selected');
                        }
                    },
                });
            };
            function getRoles(roleID){
                $('#select-worker-modal #product-selector').children().remove();
                $.ajax({
                    url: "{{ url('/') }}/workers/byrole/" + roleID,
                    method: "get",
                    success: function (response) {
                        const data = response;
                        console.log(data)
                        if (data.length > 0) {
                            data.forEach(element => $("#select-worker-modal #product-selector").append("<option value='" + element.id + "'>" + element.title + "</option>"));
                        } else {
                            $("#select-worker-modal #product-selector").append("<option>شخصی وجود ندارد!</option>");
                            $('#select-worker-modal #product-selector option:first-child').attr('selected','selected');
                        }
                    },
                });
            };

            $('#select-product-modal .category-level-one').click(function () {
                let id = $(this).val();
                $('#select-product-modal .modal-body .end-selector').remove();
                $('#select-product-modal .modal-body #category-children').remove();
                getProducts(id);
                $.ajax({
                    url: "{{ url('/') }}/categories/children/" + id,
                    method: "get",
                    success: function (response) {
                        const data = response;
                        if (data.length > 0) {
                            $('#select-product-modal .modal-body .children-selector').remove();
                            $('#select-product-modal .modal-body .end-selector').remove();

                            $('#select-product-modal .modal-body .row').append('<div class="form-group col-6 children-selector"><label for="category-children">زیر دسته</label><select class="custom-select catselect category-children" id="category-children"><option class="reset-child-id" selected>دسته مورد نظر را انتخاب کنید</option></select></div>');
                            data.forEach(element => $("#select-product-modal #category-children").append("<option class='role-level-two' value='" + element.id + "'>" + element.title + "</option>"));
                        } else {
                            $('#select-product-modal .modal-body .children-selector').remove();
                            $('#select-product-modal .modal-body .end-selector').remove();
                        }
                    },
                });
            });
            $("#select-product-modal").on("click", '.role-level-two', function () {
                let id = $(this).val();
                getProducts(id);
                $.ajax({
                    url: "{{ url('/') }}/categories/children/" + id,
                    method: "get",
                    success: function (response) {
                        const data = response;
                        if (data.length > 0) {
                            $('#select-product-modal .modal-body .end-selector').remove();

                            $('#select-product-modal .modal-body').append('<div class="form-group row end-selector"><div class="form-group col-6 end-selector"><label for="end-children">زیر دسته</label><select class="custom-select end-children catselect" id="end-children"><option class="reset-end-child-id" selected>دسته مورد نظر را انتخاب کنید</option></select></div></div>');
                            data.forEach(element => $("#select-product-modal #end-children").append("<option class='role-level-three' value='" + element.id + "'>" + element.title + "</option>"));
                        } else {
                            $('#select-product-modal .modal-body .end-selector').remove();
                        }
                    },
                });
            });
            $("#select-product-modal").on("click", '.role-level-three', function () {
                let id = $(this).val();
                getProducts(id);
            });
            $("#select-product-modal").on("click", '.reset-child-id', function () {
                $('#select-product-modal .modal-body .end-selector').remove();
                getProducts($('#select-main-category option:selected').val());
            });
            $("#select-product-modal").on("click", '.reset-end-child-id', function () {
                getProducts($('#select-product-modal  .role-level-two:selected').val());
            });
            $("#select-product-modal").on("click", '#reset-first', function () {
                $('#select-product-modal .modal-body .children-selector').remove();
                $('#select-product-modal .modal-body .end-selector').remove();
                getProducts("all");
            });
            $("#select-product-modal #product-selector").on("click", 'option', function () {
                $(".current-product-active").val($(this).text());
                $(".current-product-active").next().val($(this).val());
            });
            $("#select-product-modal .modal-footer button").click(function (){
                $(".current-product-active").val($("#select-product-modal #product-selector option:selected").text());
                $(".current-product-active").next().val($("#select-product-modal #product-selector option:selected").val());
            });

            $('#select-worker-modal .category-level-one').click(function () {
                let id = $(this).val();
                $('#select-worker-modal .modal-body .end-selector').remove();
                $('#select-worker-modal .modal-body #category-children').remove();
                getRoles(id);
                $.ajax({
                    url: "{{ url('/') }}/roles/children/" + id,
                    method: "get",
                    success: function (response) {
                        const data = response;
                        if (data.length > 0) {
                            $('#select-worker-modal .modal-body .children-selector').remove();
                            $('#select-worker-modal .modal-body .end-selector').remove();

                            $('#select-worker-modal .modal-body .row').append('<div class="form-group col-6 children-selector"><label for="category-children">زیر دسته</label><select class="custom-select catselect category-children" id="category-children"><option class="reset-child-id" selected>دسته مورد نظر را انتخاب کنید</option></select></div>');
                            data.forEach(element => $("#select-worker-modal #category-children").append("<option class='role-level-two' value='" + element.id + "'>" + element.title + "</option>"));
                        } else {
                            $('#select-worker-modal .modal-body .children-selector').remove();
                            $('#select-worker-modal .modal-body .end-selector').remove();
                        }
                    },
                });
            });
            $("#select-worker-modal").on("click", '.role-level-two', function () {
                let id = $(this).val();
                getRoles(id);
                $.ajax({
                    url: "{{ url('/') }}/roles/children/" + id,
                    method: "get",
                    success: function (response) {
                        const data = response;
                        if (data.length > 0) {
                            $('#select-worker-modal .modal-body .end-selector').remove();

                            $('#select-worker-modal .modal-body').append('<div class="form-group row end-selector"><div class="form-group col-6 end-selector"><label for="end-children">زیر دسته</label><select class="custom-select end-children catselect" id="end-children"><option class="reset-end-child-id" selected>دسته مورد نظر را انتخاب کنید</option></select></div></div>');
                            data.forEach(element => $("#select-worker-modal #end-children").append("<option class='role-level-three' value='" + element.id + "'>" + element.title + "</option>"));
                        } else {
                            $('#select-worker-modal .modal-body .end-selector').remove();
                        }
                    },
                });
            });
            $("#select-worker-modal").on("click", '.role-level-three', function () {
                let id = $(this).val();
                getRoles(id);
            });
            $("#select-worker-modal").on("click", '.reset-child-id', function () {
                $('#select-worker-modal .modal-body .end-selector').remove();
                getRoles($('#select-worker-modal option:selected').val());
            });
            $("#select-worker-modal").on("click", '.reset-end-child-id', function () {
                getRoles($('#select-worker-modal  .role-level-two:selected').val());
            });
            $("#select-worker-modal").on("click", '#reset-first', function () {
                $('#select-worker-modal .modal-body .children-selector').remove();
                $('#select-worker-modal .modal-body .end-selector').remove();
                getRoles("all");
            });
            $("#select-worker-modal #product-selector").on("click", 'option', function () {
                $('#new-entry #worker').val($(this).text());
                $('#new-entry #worker-id').val($(this).val());
            });
            $("#select-worker-modal .modal-footer button").click(function (){
                $('#new-entry #worker').val($("#select-worker-modal #product-selector option:selected").text());
                $('#new-entry #worker-id').val($("#select-worker-modal #product-selector option:selected").val());
            });

            $(".custom-add-row-icon").click(function (){
                $("#new-entry").append('<div class="form-group row custom-single-product">' + singleProductRow + '</div>');
            });
        });
    </script>
@endsection
